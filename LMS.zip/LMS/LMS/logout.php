<?php
	header("Location: index.php");
?>
<?php
	session_unset();
	session_destroy();
?>